create function print() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		RAISE NOTICE 'Произошло событие: % %', TG_EVENT, TG_TAG;
	END;
$$;
