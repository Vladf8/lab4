create function place_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		IF (NEW.Занятое_место > (SELECT count(*) FROM Человек)) THEN
			RAISE EXCEPTION 'Ошибка. Проверьте правильность занятого участником места.';
		END IF;
	RETURN NEW;
	END;
$$;
