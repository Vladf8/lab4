create function audit_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		IF (TG_OP = 'DELETE') THEN
			INSERT INTO Аудит VALUES('D',now(),TG_TABLE_NAME);
			RETURN OLD;
		ELSEIF (TG_OP = 'UPDATE') THEN
			INSERT INTO Аудит VALUES('U',now(),TG_TABLE_NAME);
			RETURN NEW;
		ELSEIF (TG_OP = 'INSERT') THEN
			INSERT INTO Аудит VALUES('I',now(),TG_TABLE_NAME);
			RETURN NEW;
		END IF;
	END;
$$;
