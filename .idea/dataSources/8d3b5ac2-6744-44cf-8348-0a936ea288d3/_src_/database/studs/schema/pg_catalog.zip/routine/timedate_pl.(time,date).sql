create function timedate_pl(time without time zone, date) returns timestamp without time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select ($2 + $1)
$$;
