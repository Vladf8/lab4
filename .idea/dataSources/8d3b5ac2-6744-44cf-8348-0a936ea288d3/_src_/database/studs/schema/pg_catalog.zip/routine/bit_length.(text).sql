create function bit_length(text) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.octet_length($1) * 8
$$;
