CREATE FUNCTION clanmembers()
  RETURNS TABLE(name text, count bigint)
LANGUAGE SQL
AS $$
SELECT
  "Название_клана",
  Count(*)
FROM "Самурай"
WHERE "Жив" AND "Название_клана" IS NOT NULL
GROUP BY "Название_клана";
$$;

