CREATE FUNCTION createclan(roninid integer, clanname text, clansymbol text, allotementname text)
  RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  IF NOT exists(SELECT 1
                FROM "Самурай"
                WHERE id = roninId AND "Название_клана" IS NULL)
  THEN
    RAISE EXCEPTION 'Самурай должен сущестовать и быть ронином';
  END IF;
  INSERT INTO "Клан" VALUES (clanName, clanSymbol, roninId);
  INSERT INTO "Земельный_надел" VALUES (allotementName, clanName);
  UPDATE Самурай
  SET Название_клана = clanName, Название_надела = allotementName
  WHERE id = roninId;
END;
$$;

