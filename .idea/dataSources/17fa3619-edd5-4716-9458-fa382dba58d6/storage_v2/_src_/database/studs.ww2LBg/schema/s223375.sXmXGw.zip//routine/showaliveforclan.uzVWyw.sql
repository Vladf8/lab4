CREATE FUNCTION showaliveforclan(clan text)
  RETURNS TABLE(id integer, name text)
LANGUAGE SQL
AS $$
SELECT
  id,
  Имя
FROM Самурай
WHERE Название_клана = clan AND Самурай.Жив = TRUE;
$$;

